package com.example.uasmoop.game;

public class InfantryCastle extends Castle {

    public InfantryCastle() {
        this.TipeCastle = Castle.Infantry;
    }

    @Override
    public double hitungPower() {

        double power = 0;
        for (Army arm: ArmiesToFight) {
            if (arm.TipeArmy == Army.Infantry) {
                power += arm.numbers + arm.numbers * Army.Infantry_Boost;
            }else {
                power += arm.numbers;
            }
        }
        return power;
    }

    @Override
    public Castle battleTo(Castle ct2) {
        return this;
    }

    @Override
    public void setArmy(Army[] Armies) {

    }

}
