package com.example.uasmoop.game;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uasmoop.R;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Activity myActivity = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);


        Castle c1 = new CastleCavalry();
        InfantryCastle c2 = new InfantryCastle();

        Castle fightingCastles[] = new Castle[2];
        fightingCastles[0] = c2;
        fightingCastles[1] = c1;

        initCastleImageBattle(fightingCastles);

        final Button btn = findViewById(R.id.btnBattle);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                BattleCastle bw = new BattleCastle(myActivity, c1, c2);
                new Thread(bw).run();


            }
        });
    }


    private void initCastleImageBattle(Castle[] castles) {


        Castle left = castles[0];
        Castle right = castles[1];

        loadCastleImage(findViewById(R.id.playerOne),left);
        loadCastleImage(findViewById(R.id.playerTwo),right);

    }

    private void loadCastleImage (ImageView iView, Castle ct) {
        if (ct instanceof CastleCavalry) {
            iView.setBackgroundResource(R.drawable.cavalry);
        }else if (ct instanceof InfantryCastle) {
            iView.setBackgroundResource(R.drawable.archer);
        }else  {
            iView.setBackgroundResource(R.drawable.cavalry);
        }
    }



}