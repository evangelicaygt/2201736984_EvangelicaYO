package com.example.uasmoop.game;

public abstract class Castle {
    public static final String Archer = "ARCHER";
    public static final String Cavalry = "CAVALRY";
    public static final String Infantry = "INFANTRY";

    public String TipeCastle;
    public Hero[] Hero;
    public Army[] Armies;

    public Army[] ArmiesToFight;

    private String name;

    public Castle(String name) {
    }

    public String getTipeCastle() {
        return this.TipeCastle;
    }

    public abstract double hitungPower();

    public abstract Castle battleTo(Castle ct2);

    public abstract void setArmy(Army[] Armies);




}
