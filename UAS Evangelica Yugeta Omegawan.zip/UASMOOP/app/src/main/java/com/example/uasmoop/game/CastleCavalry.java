package com.example.uasmoop.game;

public class CastleCavalry extends Castle {


    public CastleCavalry() {
        this.TipeCastle= Castle.Cavalry;
    }

    @Override
    public double hitungPower() {

        double power = 0;
        for (Army arm: this.ArmiesToFight) {
            if (arm.TipeArmy == Army.Cavalry) {
                power += arm.numbers + arm.numbers * Army.Cavalry_Boost;
            }else {
                power += arm.numbers;
            }
        }


        return power;
    }

    @Override
    public Castle battleTo(Castle ct2) {

        double myPower = this.hitungPower();
        double enemyPower = ct2.hitungPower();

        if (myPower >= enemyPower)
            return this;
        else
            return ct2;


    }

    @Override
    public void setArmy(Army[] Armies) {

    }
}
