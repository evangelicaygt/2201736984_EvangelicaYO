package com.example.uasmoop.game;

public class InfantryArmy extends Army{


    public InfantryArmy() {
        this.TipeArmy = Army.Infantry;
    }
}
