package com.example.uasmoop.game;

public class Archer extends Army{


    public Archer() {
        this.TipeArmy = Army.Archer;
    }

}
