package com.example.uasmoop.game;

import com.example.uasmoop.game.Castle;

public class Wood extends Castle {
    public Wood(String name) {
        super(name);
    }

    @Override
    public double hitungPower() {
        return 0;
    }

    @Override
    public Castle battleTo(Castle ct2) {
        return null;
    }

    @Override
    public void setArmy(Army[] Armies) {

    }
}
