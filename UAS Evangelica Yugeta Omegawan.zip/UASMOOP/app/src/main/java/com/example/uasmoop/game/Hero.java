package com.example.uasmoop.game;

public abstract class Hero {
    public static final String Archer = "ARCHER";
    public static final String Cavalry = "CAVALRY";
    public static final String Infantry = "INFANTRY";

    public static final double Archer_Boost = 0.2;
    public static final double Cavalry_Boost = 0.2;
    public static final double Infantry_Boost = 0.2;


}

