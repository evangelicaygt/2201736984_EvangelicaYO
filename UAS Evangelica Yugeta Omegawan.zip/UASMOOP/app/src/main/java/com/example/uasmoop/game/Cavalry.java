package com.example.uasmoop.game;

public class Cavalry extends Army{

    public Cavalry() {
        this.TipeArmy = Army.Cavalry;
    }
}
